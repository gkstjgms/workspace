import { TodoList } from './TodoList';

const Entity = [
    TodoList,
];

export default Entity;
