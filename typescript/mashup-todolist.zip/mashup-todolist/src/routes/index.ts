import { ListItem } from './listItem';

const Routes = [
    ...ListItem,
];

export default Routes;
